MobiCova Health — Launch-Readiness Pack
=======================================

Internal working documents to advance the things that gate a real public launch
of the Health Buddy, in parallel with the language translation reviews.

WHAT'S INSIDE
-------------
1. MobiCova-Health-Channel-Provisioning-Checklist.docx
   The long-lead third-party approvals: WhatsApp Business (Meta), USSD short
   code, and NCC SMS sender-ID. Has owner/status columns and lead times.
   ACTION: start WhatsApp + USSD applications first (longest lead).

2. MobiCova-Health-Compliance-Legal-Drafts.docx
   Working DRAFTS for your lawyer: NDPR privacy notice (health data), Buddy
   Terms & disclaimer/consent, and a security-review booking brief.
   NOTE: not legal advice — finalise with a qualified Nigerian lawyer.

3. MobiCova-Health-Buddy-Corpus-Phase2-Review.docx
   A second batch of 12 health passages for the clinician to review in the same
   pass (sickle cell, HIV/STIs, TB, hepatitis B, newborn care, and more).
   This is clinical content; route to the GP, not legal.

These are drafts/checklists to act on internally — not for external distribution
as-is.
