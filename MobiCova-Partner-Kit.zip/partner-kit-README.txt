MobiCova Partner Kit
====================

Insurer-agnostic materials for approaching any insurer, HMO, employer, telco or
platform partner.

WHAT'S INSIDE
-------------
1. MobiCova-for-Partners.docx
   A 2-page capability one-pager — the opener. What MobiCova does, why it's built
   for partners (white-label, SSO, API, multi-tenant), channels, languages, and
   trust & safety. Hand this to any prospect.

2. MobiCova-Health-Nigerian-Language-Proposal-TEMPLATE.docx
   The follow-on proposal for Nigerian-language support, as a reusable template.
   Fill in "[Insurer / Partner]" and "[date]"; Section 10 is a decisions
   checklist with recommended defaults.

HOW TO USE
----------
- Lead with the one-pager → book a demo → send the language proposal if relevant.
- Replace the bracketed [ ... ] placeholders per prospect.
- Everything is partner-agnostic — no single client is named.
