MobiCova Health — Translator & Clinician Pack
=============================================

Thank you for helping make MobiCova's free AI Health Buddy available in Nigeria's
major languages. This pack contains everything you need to review.

WHAT'S INSIDE
-------------
0. MobiCova-Health-Language-Go-Live-Runbook.docx
   Overview of how a language goes from draft to live, the safeguards, and the
   review roles. Read this first for context.

1. MobiCova-Health-Buddy-Corpus-Clinician-Review.docx
   The 24 English health passages the Buddy answers from. REVIEW ONCE — this
   covers ALL languages, because the Buddy translates these into each language at
   the moment of answering. Best reviewed by a GP / clinician. Mark each
   passage Approve or Amend and sign.

2. Four language Seed Kits (one per language):
     - MobiCova-Health-Pidgin-Seed-Kit.docx   (Nigerian Pidgin)
     - MobiCova-Health-Hausa-Seed-Kit.docx    (Hausa)
     - MobiCova-Health-Yoruba-Seed-Kit.docx   (Yoruba)
     - MobiCova-Health-Igbo-Seed-Kit.docx     (Igbo)
   Each contains: a style guide, a clinical glossary, the SAFETY trigger words
   (crisis/emergency/distress), the safety reply messages, and the app's fixed
   wording. Fill the "Reviewed ..." columns, edit freely, and sign.

WHO REVIEWS WHAT
----------------
- Native-speaker TRANSLATOR: glossary, fixed wording, and draft safety phrases
  in each language's Seed Kit.
- Native-speaker CLINICIAN: the corpus review doc, plus the SAFETY sections
  (3 & 4) of each Seed Kit — these protect vulnerable users.
- LEGAL reviewer: the consent/disclaimer wording (Section 4 of each Seed Kit).

IMPORTANT
---------
- Everything here is DRAFT until signed off. The drafts are a starting point to
  correct, not final copy.
- The safety sections are the most important: a cry for help must be caught in
  every language.
- When done, return the signed documents to MobiCova.

Questions: contact MobiCova Health.
